package antigravity.config;

public class RedisConfig {
}
