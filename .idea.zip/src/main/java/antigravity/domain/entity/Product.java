package antigravity.domain.entity;

import antigravity.util.BaseTimeEntity;
import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@ToString
@Getter
@Entity
@Table(name = "product")
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Product extends BaseTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String sku;
    @Column
    private String name;
    @Column
    private BigDecimal price;
    @Column
    private int quantity;
//    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    @Column(columnDefinition = "Integer Default 0")
    private Integer view;

    @OneToMany(mappedBy = "product",cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Want> wantList = new ArrayList<>();

    @Builder
    public Product(String sku, String name, BigDecimal price, int quantity){
        this.sku=sku;
        this.name=name;
        this.price=price;
        this.quantity=quantity;
    }

    @PreUpdate
    public void onPreUpdate(){
        this.updatedAt = LocalDateTime.now();
    }
    public void addTotalView(){
        this.view++;
    }
}
